package Consts;

public class Consts {
    public static final String MAIN_URL = "https://kidkiddos.com/";

}
